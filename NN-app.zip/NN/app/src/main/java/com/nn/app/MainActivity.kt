package com.nn.app

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat

// ---------------------------------------------------------------- النماذج

enum class GarmentType(val label: String) {
    TSHIRT("قميص صيفي (T-shirt)"),
    SWEATER("كنزة (أكمام طويلة)"),
    HOODIE("هودي")
}

class InkStroke(val color: Color, val width: Float, val points: SnapshotStateList<Offset>)

class PlacedImage(val bitmap: ImageBitmap, offset: Offset, scale: Float) {
    var offset by mutableStateOf(offset)
    var scale by mutableStateOf(scale)
}

/** يبني شكل الملابس ثنائي الأبعاد بإحداثيات نسبية (0..100) */
fun garmentPath(type: GarmentType, w: Float, h: Float): Path {
    val p = Path()
    fun x(v: Float) = v / 100f * w
    fun y(v: Float) = v / 100f * h
    when (type) {
        GarmentType.TSHIRT -> {
            p.moveTo(x(30f), y(6f))
            p.quadraticBezierTo(x(50f), y(22f), x(70f), y(6f))
            p.lineTo(x(98f), y(26f)); p.lineTo(x(86f), y(44f)); p.lineTo(x(76f), y(37f))
            p.lineTo(x(76f), y(94f)); p.lineTo(x(24f), y(94f)); p.lineTo(x(24f), y(37f))
            p.lineTo(x(14f), y(44f)); p.lineTo(x(2f), y(26f))
        }
        GarmentType.SWEATER -> {
            p.moveTo(x(30f), y(6f))
            p.quadraticBezierTo(x(50f), y(22f), x(70f), y(6f))
            p.lineTo(x(92f), y(14f)); p.lineTo(x(100f), y(88f)); p.lineTo(x(85f), y(90f))
            p.lineTo(x(76f), y(42f)); p.lineTo(x(76f), y(95f)); p.lineTo(x(24f), y(95f))
            p.lineTo(x(24f), y(42f)); p.lineTo(x(15f), y(90f)); p.lineTo(x(0f), y(88f))
            p.lineTo(x(8f), y(14f))
        }
        GarmentType.HOODIE -> {
            p.moveTo(x(34f), y(14f))
            p.cubicTo(x(28f), y(-4f), x(72f), y(-4f), x(66f), y(14f))
            p.lineTo(x(92f), y(20f)); p.lineTo(x(100f), y(88f)); p.lineTo(x(85f), y(90f))
            p.lineTo(x(76f), y(46f)); p.lineTo(x(76f), y(95f)); p.lineTo(x(24f), y(95f))
            p.lineTo(x(24f), y(46f)); p.lineTo(x(15f), y(90f)); p.lineTo(x(0f), y(88f))
            p.lineTo(x(8f), y(20f))
        }
    }
    p.close()
    return p
}

/** خطوط تزيينية (فتحة الرقبة، جيب الهودي) */
fun androidx.compose.ui.graphics.drawscope.DrawScope.drawDetails(type: GarmentType) {
    val w = size.width; val h = size.height
    val line = Color.Gray
    if (type == GarmentType.HOODIE) {
        val neck = Path().apply {
            moveTo(w * .34f, h * .14f)
            quadraticBezierTo(w * .5f, h * .36f, w * .66f, h * .14f)
        }
        drawPath(neck, line, style = Stroke(3f))
        val pocket = Path().apply {
            moveTo(w * .32f, h * .68f); lineTo(w * .68f, h * .68f)
            lineTo(w * .72f, h * .86f); lineTo(w * .28f, h * .86f); close()
        }
        drawPath(pocket, line, style = Stroke(3f))
    }
}

// ---------------------------------------------------------------- النشاط

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { NNApp() } }
    }
}

@Composable
fun NNApp() {
    val context = LocalContext.current

    var menuOpen by remember { mutableStateOf(false) }
    var showTypes by remember { mutableStateOf(false) }
    var garment by remember { mutableStateOf<GarmentType?>(null) }

    val strokes = remember { mutableStateListOf<InkStroke>() }
    val images = remember { mutableStateListOf<PlacedImage>() }
    var penMode by remember { mutableStateOf(true) }
    var penColor by remember { mutableStateOf(Color.Black) }
    var penWidth by remember { mutableFloatStateOf(8f) }
    var canvasSize by remember { mutableStateOf(IntSize.Zero) }

    fun loadImage(uri: Uri) {
        try {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            var sample = 1
            while (bounds.outWidth / sample > 1600) sample *= 2
            val opts = BitmapFactory.Options().apply { inSampleSize = sample }
            val bmp = context.contentResolver.openInputStream(uri)?.use {
                BitmapFactory.decodeStream(it, null, opts)
            } ?: return
            val scale = canvasSize.width * 0.4f / bmp.width
            val off = Offset(
                (canvasSize.width - bmp.width * scale) / 2f,
                (canvasSize.height - bmp.height * scale) / 2f
            )
            images.add(PlacedImage(bmp.asImageBitmap(), off, scale))
            penMode = false
            Toast.makeText(context, "حرّك الصورة بإصبع وكبّرها بإصبعين. اضغط «قلم» للرسم.", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(context, "تعذّر تحميل الصورة", Toast.LENGTH_SHORT).show()
        }
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        uri?.let { loadImage(it) }
    }
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) picker.launch("image/*")
        else Toast.makeText(context, "لا يمكن إضافة صورة بدون صلاحية الوصول للصور", Toast.LENGTH_LONG).show()
    }

    fun onAddImage() {
        val perm = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_IMAGES
        else Manifest.permission.READ_EXTERNAL_STORAGE
        if (ContextCompat.checkSelfPermission(context, perm) == PackageManager.PERMISSION_GRANTED) {
            picker.launch("image/*")
        } else {
            permissionLauncher.launch(perm)
        }
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(Color(0xFF9E9E9E)) // الشاشة الرمادية
            .systemBarsPadding()
    ) {
        // ---------- منطقة العمل
        garment?.let { type ->
            Column(
                Modifier
                    .fillMaxSize()
                    .padding(start = 12.dp, end = 80.dp, top = 12.dp, bottom = 12.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Canvas(
                    Modifier
                        .fillMaxWidth()
                        .aspectRatio(1f)
                        .onSizeChanged { canvasSize = it }
                        .pointerInput(penMode, penColor, penWidth, type) {
                            if (penMode) {
                                detectDragGestures(
                                    onDragStart = { pos ->
                                        strokes.add(InkStroke(penColor, penWidth, mutableStateListOf(pos)))
                                    },
                                    onDrag = { change, _ ->
                                        strokes.lastOrNull()?.points?.add(change.position)
                                    }
                                )
                            } else {
                                detectTransformGestures { _, pan, zoom, _ ->
                                    images.lastOrNull()?.let {
                                        it.offset += pan
                                        it.scale = (it.scale * zoom).coerceIn(0.05f, 10f)
                                    }
                                }
                            }
                        }
                ) {
                    val path = garmentPath(type, size.width, size.height)
                    drawPath(path, Color.White)
                    // كل ما بداخل clipPath لا يظهر خارج المجسم
                    clipPath(path) {
                        images.forEach { img ->
                            withTransform({
                                translate(img.offset.x, img.offset.y)
                                scale(img.scale, img.scale, pivot = Offset.Zero)
                            }) { drawImage(img.bitmap) }
                        }
                        strokes.forEach { s ->
                            if (s.points.size == 1) {
                                drawCircle(s.color, s.width / 2f, s.points[0])
                            } else {
                                val sp = Path().apply {
                                    moveTo(s.points[0].x, s.points[0].y)
                                    for (i in 1 until s.points.size) lineTo(s.points[i].x, s.points[i].y)
                                }
                                drawPath(sp, s.color, style = Stroke(s.width, cap = StrokeCap.Round, join = StrokeJoin.Round))
                            }
                        }
                    }
                    drawPath(path, Color.DarkGray, style = Stroke(4f, join = StrokeJoin.Round))
                    drawDetails(type)
                }

                // ---------- أدوات التصميم
                Surface(shape = MaterialTheme.shapes.large, color = Color(0xFFEEEEEE)) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            FilterChip(
                                selected = penMode,
                                onClick = { penMode = !penMode },
                                label = { Text("✏️ قلم") }
                            )
                            AssistChip(onClick = { onAddImage() }, label = { Text("🖼️ صورة") })
                            AssistChip(onClick = {
                                if (strokes.isNotEmpty()) strokes.removeAt(strokes.lastIndex)
                                else if (images.isNotEmpty()) images.removeAt(images.lastIndex)
                            }, label = { Text("↩ تراجع") })
                        }
                        Text("سماكة الخط: ${penWidth.toInt()}", fontSize = 13.sp)
                        Slider(value = penWidth, onValueChange = { penWidth = it }, valueRange = 2f..40f)
                        Text("لون الخط", fontSize = 13.sp)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf(
                                Color.Black, Color.Red, Color(0xFFFF9800), Color.Yellow,
                                Color(0xFF4CAF50), Color.Blue, Color(0xFF9C27B0), Color.White
                            ).forEach { c ->
                                Box(
                                    Modifier
                                        .size(34.dp)
                                        .clip(CircleShape)
                                        .background(c)
                                        .border(
                                            if (c == penColor) 3.dp else 1.dp,
                                            if (c == penColor) Color(0xFF1976D2) else Color.Gray,
                                            CircleShape
                                        )
                                        .clickable { penColor = c; penMode = true }
                                )
                            }
                        }
                    }
                }
            }
        }

        // ---------- زر الزائد على جانب الشاشة
        Column(
            Modifier
                .align(Alignment.CenterEnd)
                .padding(end = 12.dp),
            horizontalAlignment = Alignment.End,
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            if (menuOpen) {
                ExtendedFloatingActionButton(
                    onClick = { showTypes = true; menuOpen = false },
                    text = { Text("إضافة الملابس") },
                    icon = {}
                )
            }
            FloatingActionButton(onClick = { menuOpen = !menuOpen }) {
                Text(if (menuOpen) "×" else "+", fontSize = 28.sp)
            }
        }
    }

    // ---------- خيارات الملابس
    if (showTypes) {
        AlertDialog(
            onDismissRequest = { showTypes = false },
            title = { Text("اختر نوع الملابس") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    GarmentType.values().forEach { t ->
                        Button(
                            onClick = {
                                garment = t
                                strokes.clear(); images.clear()
                                penMode = true
                                showTypes = false
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text(t.label) }
                    }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { showTypes = false }) { Text("إلغاء") } }
        )
    }
}
